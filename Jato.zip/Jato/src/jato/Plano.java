/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jato;

public class Plano {
    private String nome;
    private String descricao;
    private int lavagensPorMes;
    private double precoMensal;

    // Construtor
    public Plano(String nome, String descricao, int lavagensPorMes, double precoMensal) {
        this.nome = nome;
        this.descricao = descricao;
        this.lavagensPorMes = lavagensPorMes;
        this.precoMensal = precoMensal;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getLavagensPorMes() {
        return lavagensPorMes;
    }

    public void setLavagensPorMes(int lavagensPorMes) {
        this.lavagensPorMes = lavagensPorMes;
    }

    public double getPrecoMensal() {
        return precoMensal;
    }

    public void setPrecoMensal(double precoMensal) {
        this.precoMensal = precoMensal;
    }
}
