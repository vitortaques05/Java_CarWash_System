/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jato;

/**
 *
 * @author Aluno TDS
 */
public class Agenda {
    
    private String dia;
    private String hora;
    
    
    public Agenda(String dia, String hora){
        this. dia = dia;
        this.hora = hora;
    }
    
    public String getDia(){
        return dia;
    }
    
    public void setDia(String dia){
        this.dia = dia;
    }
    
    public String getHora(){
        return hora;
    }
    
    public void setHora(String hora){
        this.hora = hora;
    }
    
    
}
