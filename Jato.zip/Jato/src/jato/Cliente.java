package jato;

public class Cliente {
    private String nome;
    private String sobrenome;
    private String endereco;
    private String telefone;
    private String sexo;
    private String dataNascimento;
    private Carro carro;
    private Plano plano;
    
    
    // Construtor vazio (padrão)
    public Cliente() {
        // Inicialize os campos com valores padrão, se necessário
        this.nome = "";
        this.sobrenome = "";
        this.endereco = "";
        this.telefone = "";
        this.sexo = "";
        this.dataNascimento = "";
      
    }
    
        // Construtor vazio (padrão)
    public Cliente(String nome, String sobrenome, String endereco, String telefone, String sexo, String dataNascimento) {
        // Inicialize os campos com valores padrão, se necessário
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.sexo = sexo;
        this.dataNascimento = dataNascimento;
        this.carro = null;
        this.plano = null;
      
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    
    public Carro getCarro (){
        return carro;
    }
    
    public void setCarro (Carro carro){
        this.carro = carro;
    }
    
    public Plano getPlano(){
        return plano;
    }
    
    public void setPlano (Plano plano){
        this.plano = plano;
    }
}
